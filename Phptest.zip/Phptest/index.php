<?php

if(isset($_POST['submit'])){
	if(isset($_POST['first_name']) && $_POST['first_name']==''){
		echo "Kindly enter the first name";
	}
	if(isset($_POST['last_name']) && $_POST['last_name']==''){
		echo "Kindly enter the last name";
	}
	if(isset($_POST['mob_number']) && $_POST['mob_number']==''){
		echo "Kindly enter the Mobile Number";
	}
	if(isset($_POST['dob']) && $_POST['dob']==''){
		echo "Kindly enter the date of birth";
	}
	
	if(isset($_FILE['adhar_img']) && $_FILE['adhar_img']==''){
		echo "Kindly upload adhar card image";
	}else{
	
		$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES["adhar_img"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

		$check = getimagesize($_FILES["adhar_img"]["tmp_name"]);
		if($check !== false) {
			$uploadOk = 1;
			// Check if file already exists
			if (file_exists($target_file)) {
				echo "Sorry, adhar card image already exists.";
				$uploadOk = 0;
			}
		// Check file size
		if ($_FILES["adhar_img"]["size"] > 500000) {
			echo "Sorry, your adhar card image is too large.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "<br/>Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		
		if ($uploadOk == 0) {
			echo "<br/>Sorry, your adhar card image was not uploaded.";
		} else {
			if (move_uploaded_file($_FILES["adhar_img"]["tmp_name"], $target_file)) {
				echo "<br/>The Adhar card image ". basename( $_FILES["adhar_img"]["name"]). " has been uploaded.";
			} else {
				echo "<br/>Sorry, there was an error uploading your file.";
			}
		}
			
		} else {
			echo "<br />Adhar card file is not an image.";
		}

		
	}
	
	if(isset($_FILE['pan_img']) && $_FILE['pan_img']==''){
		echo "Kindly upload pan card image";
	}else{
	
		$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES["pan_img"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

		$check = getimagesize($_FILES["pan_img"]["tmp_name"]);
		if($check !== false) {
			$uploadOk = 1;
			// Check if file already exists
			if (file_exists($target_file)) {
				echo "<br/>Sorry, file already exists.";
				$uploadOk = 0;
			}
			// Check file size
			if ($_FILES["pan_img"]["size"] > 500000) {
				echo "<br/>Sorry, your file is too large.";
				$uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
				echo "<br/>Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
			}
			
			if ($uploadOk == 0) {
				echo "<br/>Sorry, your pan card image was not uploaded.";
			} else {
				if (move_uploaded_file($_FILES["pan_img"]["tmp_name"], $target_file)) {
					echo "<br />The pan card image ". basename( $_FILES["pan_img"]["name"]). " has been uploaded.";
				} else {
					echo "<br/>Sorry, there was an error uploading your file.";
				}
			}
		} else {
			echo "<br />Pan card fileis not an image.";
			$uploadOk = 0;
		}

	echo "<br/><br/><br /><b>Form submitted successfuly</b>";	
		
	}
} else {

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    
    <!-- Title Page-->
    <title>Php Test</title>

    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>


    <!-- Main JS-->
    <script src="js/global.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="https://jqueryui.com/resources/demos/style.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
  
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
</head>

<body>
    <div class="page-wrapper bg-dark p-t-100 p-b-50">
        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">KYC details form</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action=""  enctype="multipart/form-data">
                        <div class="form-row">
                            <div class="name">First name</div>
                            <div class="value">
                                <input class="input--style-6" type="text" name="first_name" required>
                            </div>
                        </div>
						
                        <div class="form-row">
                            <div class="name">Last name</div>
                            <div class="value">
                                <input class="input--style-6" type="text" name="last_name"  required>
                            </div>
                        </div>
						
                        <div class="form-row">
                            <div class="name">Mobile No </div>
                            <div class="value">
                                <input class="input--style-6" type="number" name="mob_number"  required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Date Of Birth</div>
                            <div class="value">
                                <input class="input--style-6" type="text" name="dob" id="datepicker" required>
                        </div>
                        </div>
						
                        <div class="form-row">
                            <div class="name">Upload Adhar Card</div>
                            <div class="value">
                                <div >
                                    <input required  type="file" name="adhar_img" id="file" accept="image/*">
                                    
                                </div>
                                <div class="label--desc">Upload your adhard card image. Max image size 50 MB</div>
                            </div>
                        </div>
						
						
                        <div class="form-row">
                            <div class="name">Upload Pan Card</div>
                            <div class="value">
                                <div >
                                    <input required  type="file" name="pan_img" id="file1"accept="image/*" >
                                    
                                </div>
								
                                <div class="label--desc">Upload your pan card image. Max image size 50 MB</div>
                            </div>
                        </div>
						

					<div class="card-footer">
						<input type="submit" name="submit"  class="btn btn--radius-2 btn--blue-2"  value="Submit"/>
					</div>
					</div>	
                 </form>
            </div>
        </div>
    </div>


</body>
</html>
<?php }?>
